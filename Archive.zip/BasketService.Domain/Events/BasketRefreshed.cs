namespace BasketService.Domain.Events;

public record BasketRefreshed(DateTime DateTime);