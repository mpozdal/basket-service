namespace BasketService.Domain.Events;

public record BasketCreated(Guid UserId);