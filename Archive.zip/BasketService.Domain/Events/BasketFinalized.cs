namespace BasketService.Domain.Events;

public record BasketFinalized(Guid BasketId);